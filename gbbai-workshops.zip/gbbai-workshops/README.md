# gbbai-workshops

Welcome to the gbbai-workshops repository! This collection of workshops is designed to help you learn and implement AI solutions using Azure's powerful AI services. These hands-on workshops will guide you through building practical AI applications while leveraging Azure OpenAI, AI Search, and other cutting-edge technologies.